# assign1
This program reads blocks into memory and writes them on a disk
